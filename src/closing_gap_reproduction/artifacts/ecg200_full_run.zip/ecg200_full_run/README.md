# Full ECG200 run package

This package is ready to run on a larger-memory Linux machine that you control.
It has not been run on a remote server. The full runs on the original PC were
killed during MOSEK model construction, with a confirmed abnormal-class OOM.

All 200 ECG200 samples are included: 100 train and 100 test, comprising 133
normal and 67 abnormal. The cached archive data is still loaded through
`aeon.datasets.load_classification`. Every heartbeat retains all 96 points,
with time j/95, the original amplitudes, and uniform mass 1/96.

Algorithm 4 runs at t=2 using MOSEK and the existing default parameters.
The candidate-helper signature fix is included. No PDLP, candidate cap,
subsampling, or solver implementation change is used. Full LP sizes are
163,034,592 variables for normal and 41,377,056 for abnormal. The necessary
peak memory has not been measured; the original 3.5 GiB WSL RAM plus 1 GiB
swap was insufficient. A larger machine is not a guarantee of completion.

Setup (Python 3.12 was used for local validation):

    python3 -m venv .venv
    source .venv/bin/activate
    python -m pip install -r requirements-ecg200.txt

Configure your own MOSEK license in that environment. No license or private
credentials are included. Confirm the license is valid on the destination.

Validate and run:

    python -B -m unittest discover -s code -p test_w1_candidates.py -v
    bash scripts/run_ecg200_full.sh

The wrapper runs the two full classes as separate processes, preserving
per-class logs and process exit statuses if a child process is killed.
It uses the active python3, or an executable set in the PYTHON environment
variable. Existing ECG200 output files are protected against overwriting.
Use a fresh extraction directory for another complete attempt.

Successful outputs will be under results/normal and results/abnormal:
NPZ with S, z, objective and runtime; CSV of time, amplitude and mass;
JSON metadata; comparison PNG of inputs and weighted barycenter atoms.
Input NPZs and waveform PNGs are also saved. A failed or killed process
may leave only inputs; those are not computed barycenters.

manifest.json contains the SHA256 hash of every packaged source/data file.
